document.getElementById('openCardButton').addEventListener('click', () => {
    const card = document.getElementById('card');
    const front = document.querySelector('.front');
    const back = document.querySelector('.back');
    const audio = document.getElementById('birthdaySong');

    front.style.transform = 'rotateY(-180deg)';
    back.style.transform = 'rotateY(0deg)';
    back.style.opacity = '1';
    
    setTimeout(() => {
        front.classList.add('hidden');
        back.classList.remove('hidden');
        audio.play();


        const images = document.querySelectorAll('.gallery img');
        images.forEach((img, index) => {
            img.style.animationDelay = `${index * 0.0}s`;
        });


        createBalloons();


        showSlides(slideIndex);
    }, 600); 
});

function createBalloons() {
    const balloonsContainer = document.createElement('div');
    balloonsContainer.classList.add('balloons');
    document.body.appendChild(balloonsContainer);

    for (let i = 0; i < 20; i++) {
        const balloon = document.createElement('div');
        balloon.classList.add('balloon');
        balloon.style.left = `${Math.random() * 100}%`;
        balloon.style.backgroundColor = getRandomColor();
        balloon.style.animationDelay = `${Math.random() * 5}s`;
        balloonsContainer.appendChild(balloon);
    }
}

function getRandomColor() {
    const colors = ['#FF5733', '#FFBD33', '#33FF57', '#3357FF', '#BD33FF'];
    return colors[Math.floor(Math.random() * colors.length)];
}


let slideIndex = 0;

function showSlides() {
    const slides = document.querySelectorAll('.slide');
    slides.forEach((slide, index) => {
        slide.style.display = 'none';
    });
    slideIndex++;
    if (slideIndex > slides.length) {
        slideIndex = 1;
    }
    slides[slideIndex - 1].style.display = 'block';
    setTimeout(showSlides, 2000); 
}

// Manual controls
document.querySelector('.prev').addEventListener('click', () => {
    changeSlide(-1);
});
document.querySelector('.next').addEventListener('click', () => {
    changeSlide(1);
});

function changeSlide(n) {
    showSlides(slideIndex += n);
}
